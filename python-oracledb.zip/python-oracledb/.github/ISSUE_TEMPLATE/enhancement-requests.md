---
name: Enhancement Requests
about: Use this for enhancement requests
title: ''
labels: enhancement
assignees: ''

---

<!--

Thank you for using python-oracledb.

Review existing enhancement requests: https://github.com/oracle/python-oracledb/labels/enhancement

Please answer these questions so we can help you.

Use Markdown syntax, see https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax

-->

1. Describe your new request in detail

2. Give supporting information about tools and operating systems.  Give relevant product version numbers
