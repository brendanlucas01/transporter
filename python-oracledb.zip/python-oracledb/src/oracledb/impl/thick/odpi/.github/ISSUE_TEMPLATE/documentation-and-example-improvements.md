---
name: Documentation and Example Improvements
about: Use this to suggest changes to documentation and examples
title: ''
labels: enhancement
assignees: ''

---

<!--

Thank you for using ODPI-C.

Please answer these questions so we can help you.

Use Markdown syntax, see https://docs.github.com/github/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax

-->

1. What is the link to the documentation section that needs improving?

2. Describe the confusion

3. Suggest changes that would help
